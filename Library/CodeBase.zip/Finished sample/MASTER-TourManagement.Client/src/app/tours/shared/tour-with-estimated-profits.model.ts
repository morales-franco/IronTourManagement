import { Tour } from "./tour.model";

export class TourWithEstimatedProfits extends Tour {
    estimatedProfits: number;
}
