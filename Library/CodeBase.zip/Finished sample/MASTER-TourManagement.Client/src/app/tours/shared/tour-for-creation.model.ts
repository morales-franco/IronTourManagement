import { TourAbstractBase } from "./tour-abstract-base.model";

export class TourForCreation extends TourAbstractBase {
    bandId: string;
}
