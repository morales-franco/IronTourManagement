import { TourAbstractBase } from "./tour-abstract-base.model";

export class Tour extends TourAbstractBase {
    tourId: string;    
    band: string;
}
