import { TourAbstractBase } from "./tour-abstract-base.model";

export class TourForUpdate extends TourAbstractBase {
}
