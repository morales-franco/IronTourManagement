import { ShowAbstractBase } from "./show-abstract-base.model";

export class Show extends ShowAbstractBase  {
    showId: string; 
}
