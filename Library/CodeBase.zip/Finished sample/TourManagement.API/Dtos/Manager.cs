﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TourManagement.API.Dtos
{
    public class Manager
    {
        public Guid ManagerId { get; set; }
        public string Name { get; set; }
    }
}
