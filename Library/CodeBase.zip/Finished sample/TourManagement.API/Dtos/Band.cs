﻿using System;

namespace TourManagement.API.Dtos
{
    public class Band
    {
        public Guid BandId { get; set; }
        public string Name { get; set; }
    }
}
